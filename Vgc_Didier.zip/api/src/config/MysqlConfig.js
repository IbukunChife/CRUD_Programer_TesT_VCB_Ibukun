module.exports = {
    host:'172.17.0.2',
    port:'3306',
    user: 'root',
    password: 'provas',
    database:'medicos'
};